import React from 'react';

export default function Schedule() {
  return <div style={{padding:'2rem'}}><h1>Schedule Page</h1></div>;
}