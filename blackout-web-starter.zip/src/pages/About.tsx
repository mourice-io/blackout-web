import React from 'react';

export default function About() {
  return <div style={{padding:'2rem'}}><h1>About Page</h1></div>;
}