import React from 'react';

export default function Reviews() {
  return <div style={{padding:'2rem'}}><h1>Reviews Page</h1></div>;
}