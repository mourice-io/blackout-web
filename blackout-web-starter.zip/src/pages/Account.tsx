import React from 'react';

export default function Account() {
  return <div style={{padding:'2rem'}}><h1>Account Page</h1></div>;
}