import React from 'react';

export default function Tracking() {
  return <div style={{padding:'2rem'}}><h1>Tracking Page</h1></div>;
}